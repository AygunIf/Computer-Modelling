package tabulationmethod;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author aygun
 */
public class TabulationMethod {
 
    float func(float x)
    { 
        System.out.println (x*x+x-1 + " --- " + x);
            return (float) (x*x+x-1);
            
//x*x*x+x-1; //(Math.exp(-x)-x*x); //Math.pow(Math.E, -x)-x*x*x;
    }
    void tabul(float a,float b,float c,float eps,boolean check)
    {
        while (!check) {            
            if (func(a)*func(b)<0)
            {
                c=(a+b)/2; 
        
            if (func(c)*func(a)<0) 
            {
                b=c;
                check = Math.abs(a-c)<eps;
            }
            else if (func(c)*func(b)<0) 
            {
                a=c;
            check = Math.abs(b-c)<eps;                   
            } 
        } 
        if (check==true) 
          {
            System.out.println("All the points of ["+a+","+b+"] interval satisfy equation with accuracy Ɛ = " + eps + ".");
          }
        }
    }
    public static void main(String[] args)throws IOException{
       
        float a,b,c=0,eps;
        boolean check=false;
        TabulationMethod obj = new TabulationMethod();
        try (Scanner point = new Scanner(System.in)) {
            System.out.println("Enter value of initial border: ");
            a=point.nextFloat();
            System.out.println("Enter value of final border: ");
            b=point.nextFloat();
            System.out.println("Enter epsilon value: ");
            eps=point.nextFloat();
        }    
        obj.tabul(a,b,c,eps,check);
    }    
}
