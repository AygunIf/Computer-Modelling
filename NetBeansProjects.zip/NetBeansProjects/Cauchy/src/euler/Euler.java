/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;
import java.io.*;
import java.util.Scanner;

public class Euler {
    
 float func(float x, float y)
        {
            return (x/y);
        }    
 void euler(float x0,float y, float h, float x)
 {
     while(x0<x)
     {
         y=y+h*func(x0,y);
         x0=x0+h;
     }
     System.out.println("Approximate solution at x = " + x + " is " + y);
             }
 
 public static void main(String[] args)throws IOException
 {
  Euler obj = new Euler();
  float x0, y0, h, x;
  try (Scanner point = new Scanner(System.in)) {
      System.out.println("Enter an initial value of x: ");
      x0 = point.nextFloat();
      System.out.println("Enter an initial value of y: ");
      y0 = point.nextFloat();
      System.out.println("Enter h: ");
      h = point.nextFloat();
      System.out.println("Enter a final value of x: ");
      x = point.nextFloat();
     }

  obj.euler(x0, y0, h, x);
       
    }
    
}
