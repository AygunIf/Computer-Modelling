/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runge.kutta_2;

import java.io.IOException;
import java.util.Scanner;

public class RungeKutta_2 {
    float func(float x, float y)
    {
        return (1-y*y);
    }
   
    void runge(float x0, float y, float h, float x)
    { float init = -0;
        while (x0<x) {            
           init=y;
            y = init + h*func(x0+h/2, init+h/2*func(x0, init));
            x0=x0+h;
        }
        System.out.println("Approximate solution at x = " + x + " is " + y);
    }
    public static void main(String[] args)throws IOException
    {
        RungeKutta_2 obj = new RungeKutta_2();
        float x0, y, h, x;
        try (Scanner point = new Scanner(System.in)){
            System.out.println("Enter an initial value of x: ");
            x0=point.nextFloat();
            System.out.println("Enter an initial value of y: ");
            y=point.nextFloat();
            System.out.println("Enter h: "); 
            h= point.nextFloat();
            System.out.println("Enter a final value of x : ");
            x=point.nextFloat();
        } 
        obj.runge(x0,y,h,x);
      
        
    }
    
}
